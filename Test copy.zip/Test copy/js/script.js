/*Header js start */
$(window).scroll(function() {
    if ($(this).scrollTop() > 120) {
        $('header').addClass('fixed');
    } else {
        $('header').removeClass('fixed');
    }
});
/* Header js end */

/* Client logo slider js start */
$('.client-logo-slider').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    responsive: [{
            breakpoint: 1025,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false
            }
        },
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false
            }
        },
        {
            breakpoint: 769,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
    ]
});
/* Client logo slider js end */

/* Animation js start */
AOS.init({
    duration: 1200,
})
/* Animation js end */